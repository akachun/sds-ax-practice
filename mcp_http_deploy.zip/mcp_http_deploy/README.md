# 교육용 MCP 서버

## 파일

```
mcp_server_http.py            서버 (도구 4개, transport="http")
make_data.py                  교육용 더미 데이터 생성 (이미지 빌드 때 실행됨)
Dockerfile                    python:3.12-slim 기반
docker-compose.yml            mcp-server + gateway 2개 서비스
nginx/default.conf.template   인증, 사용량 제한, 호출 기록 설정
client_test.py                접속 확인용 (langchain-mcp-adapters)
```

## 실행

```bash
docker compose up -d
docker compose ps                   
python client_test.py               
docker compose down
```

## uvicorn

fastmcp의 `mcp.run(transport="http")`이 내부에서 uvicorn을 띄웁니다.
서버 기동 로그에서 확인할 수 있습니다.

```
INFO:     Uvicorn running on http://0.0.0.0:8000
```
- uvicorn은 비동기라 단일 프로세스로도 여러 클라이언트를 동시에 받습니다.
- MCP streamable HTTP는 세션 상태를 프로세스 메모리에 둡니다.
트래픽이 늘면 워커가 아니라 컨테이너 개수를 늘리고 로드밸런서를 앞에 두는게 낫습니다.

## Agent에서 연결

`mcp_agent.py`의 설정에서 transport와 url만 바뀝니다.

```python
# stdio (4일차)
client = MultiServerMCPClient({
    "company": {"command": sys.executable, "args": ["mcp_server.py"], "transport": "stdio"},
})

# streamable HTTP (이 서버, 게이트웨이 경유)
client = MultiServerMCPClient({
    "company": {
        "url": "http://서버주소:8080/mcp",
        "transport": "streamable_http",
        "headers": {"X-API-Key": "발급받은키"},
    },
})
```

나머지 코드(get_tools, create_agent)는 그대로 두었습니다!
