# MCP 서버 접속 확인
import asyncio
import os

from langchain_mcp_adapters.client import MultiServerMCPClient

URL = os.environ.get("MCP_URL", "http://localhost:8080/mcp")
API_KEY = os.environ.get("MCP_API_KEY", "demo-key-change-me")


async def main():
    client = MultiServerMCPClient(
        {
            "company": {
                "url": URL,
                "transport": "streamable_http",
                "headers": {"X-API-Key": API_KEY},
            }
        }
    )
    tools = await client.get_tools()
    print(f"도구 {len(tools)}개:", [t.name for t in tools])

    team_tool = next(t for t in tools if t.name == "list_team_members")
    result = await team_tool.ainvoke({"team": "클라우드운영팀"})
    print("list_team_members('클라우드운영팀') ->")
    print(str(result)[:300])


if __name__ == "__main__":
    asyncio.run(main())
